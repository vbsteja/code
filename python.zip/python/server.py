# -*- coding: utf-8 -*-
import xml.etree.ElementTree as ET 
import requests
import os,json
import urllib
import codecs
from flask import Flask,render_template,flash, request, redirect, url_for
app = Flask(__name__,static_url_path='')

from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'files'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@app.route('/')
def hello_world():
    return render_template('index.html')

@app.route('/<string:page_name>/')
def render_static(page_name):
    return render_template(page_name)


@app.route('/fetch_entities', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        file_ = request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        return get_entities(file_.read())
        
def get_entities(data):
    Facet_matches = [['mykeyword','court_name'],
                     ['mykeyword','CORAM'],
                     ['mykeyword','reserved'],
                     ['mykeyword','pronounced'],
                     ['mykeyword','defendant_name'],
                     ['mykeyword','Section']]
    Entities = dict()
    params = {"collection":"col_59621","text":data}
    res = requests.get('http://win-rtuo17claij:8393/api/v10/analysis/text',urllib.urlencode(params))
    #res = result.text.encode("utf-8")
    #output.write(" ".join(unicode(text)) + "\n")
    file = open("resp_text.xml", "w")
    try:
        
        file.write(res.text.encode('ascii','ignore'))
    except Exception:
        pass
    file.close()
    tree = ET.parse("resp_text.xml")
    root = tree.getroot()
    content = root[0].text
    Facets = root[1][1]
    for Facet in Facets:
        facet_text = set(map(lambda a: a.text ,Facet.iter()))
        for facet_match in Facet_matches:
            #print(facet_match)
            #print(facet_text)
            if set(facet_match).issubset(facet_text):
                print(facet_match)
                print(Facet.get('Begin'))
                print(content)
                if 'Section' in facet_text or 'Sections' in facet_text:
                    try:
                        
                        Entities[facet_match[1]] +=  content[int(Facet.get('Begin')):int(Facet.get('End'))]
                    except Exception:
                        pass
                else:
                    Entities[facet_match[1]] =  content[int(Facet.get('Begin')):int(Facet.get('End'))]
    print(Entities)
    #return list(Entities.values())
    return json.dumps(Entities)
    

@app.route('/save_employee')
def fetch_entities():
	
	return reply

#port = 5000 #+ random.randint(0, 999)
url = "0.0.0.0"
app.run(host=url,port=8080,debug=False)
