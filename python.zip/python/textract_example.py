import textract

text = textract.process("ordjud.pdf")
